export const business = {
  name: "Standard Rope & Hardware",
  owner: "Aziz Ur Rahman Khan",
  phone: "+919977776724",
  phoneDisplay: "+91 99777 76724",
  established: 1970,
  tagline: "Trusted Rope, Net & Hardware Solutions Since 1970",
  address: {
    line1: "1 Raja Ram Patel Market",
    line2: "J.P. Marg, Dewas",
    line3: "Madhya Pradesh 455001",
    full: "1 Raja Ram Patel Market, J.P. Marg, Dewas, Madhya Pradesh 455001",
  },
};

export const whatsappLink = `https://wa.me/${business.phone.replace("+", "")}`;
export const callLink = `tel:${business.phone}`;

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/rope-solutions", label: "Rope Solutions" },
  { href: "/net-solutions", label: "Net Solutions" },
  { href: "/hardware-solutions", label: "Hardware Solutions" },
  { href: "/gallery", label: "Gallery" },
  { href: "/reviews", label: "Reviews" },
  { href: "/contact", label: "Contact" },
];

export const trustStats = [
  { value: 50, suffix: "+", label: "Years in Operation" },
  { value: 12000, suffix: "+", label: "Customers Served" },
  { value: 8, suffix: "", label: "States Reached" },
  { value: 500, suffix: " km", label: "Service Radius" },
];

export const timeline = [
  {
    year: "1970",
    title: "The first coil is sold",
    text: "Aziz Ur Rahman Khan's father opens a small rope counter in Dewas' Raja Ram Patel Market, supplying farmers and cart operators with hand-laid cotton and jute rope.",
  },
  {
    year: "1985",
    title: "Industrial demand arrives",
    text: "As Dewas' textile and engineering units grow, the shop expands into synthetic and nylon rope for transport binding and machine lashing.",
  },
  {
    year: "1998",
    title: "Net solutions added",
    text: "Shade nets and agricultural netting are introduced to serve the region's expanding farming community through harsh summers.",
  },
  {
    year: "2010",
    title: "Regional supplier status",
    text: "Standard Rope & Hardware becomes a recognised bulk supplier to construction and warehousing companies across Malwa.",
  },
  {
    year: "Today",
    title: "Three generations of trust",
    text: "Now run with the same hands-on attention to quality, serving customers within a 500 km radius of Dewas.",
  },
];

export type Product = {
  slug: string;
  name: string;
  spec: string;
  description: string;
  uses: string[];
};

export const ropeProducts: Product[] = [
  {
    slug: "nylon-rope",
    name: "Nylon Rope",
    spec: "DIA 6–32 MM",
    description:
      "High-tenacity nylon rope with strong abrasion resistance, used wherever a clean, weatherproof hold is required.",
    uses: ["Transport lashing", "Marine & well use", "General industrial rigging"],
  },
  {
    slug: "industrial-rope",
    name: "Industrial Rope",
    spec: "HEAVY DUTY",
    description:
      "Built for factories and warehouses — engineered for repeated load cycles on machinery, hoists and material handling.",
    uses: ["Hoisting", "Machine tie-downs", "Warehouse handling"],
  },
  {
    slug: "agricultural-rope",
    name: "Agricultural Rope",
    spec: "FARM GRADE",
    description:
      "Durable, weather-resistant rope for farms — fencing, baling, and securing equipment through every season.",
    uses: ["Fencing", "Baling & bundling", "Tool & gate securing"],
  },
  {
    slug: "animal-rope",
    name: "Animal Rope",
    spec: "SOFT-HAND FINISH",
    description:
      "Soft-finish cotton and synthetic blends designed for safe, comfortable handling and tethering of livestock.",
    uses: ["Tethering", "Leading & handling", "Cattle yard fittings"],
  },
  {
    slug: "transport-rope",
    name: "Transport Rope",
    spec: "HIGH TENSILE",
    description:
      "High-tensile rope built specifically for securing loads on trucks and trailers across long-haul routes.",
    uses: ["Load securing", "Tarpaulin tie-down", "Goods carrier binding"],
  },
  {
    slug: "construction-rope",
    name: "Construction Rope",
    spec: "SITE READY",
    description:
      "Site-grade rope for scaffolding, hoisting materials, and general safety use on active construction sites.",
    uses: ["Scaffolding ties", "Material hoisting", "Site safety lines"],
  },
  {
    slug: "heavy-duty-rope",
    name: "Heavy Duty Rope",
    spec: "MAX LOAD",
    description:
      "Our highest breaking-strength rope, supplied to clients who cannot compromise on load capacity.",
    uses: ["Crane & winch use", "Heavy load anchoring", "Industrial pulley systems"],
  },
  {
    slug: "multipurpose-rope",
    name: "Multipurpose Rope",
    spec: "ALL-ROUND",
    description:
      "A flexible, reliable everyday rope stocked in bulk for general commercial and household requirements.",
    uses: ["General binding", "Storage & packing", "Everyday utility"],
  },
];

export const netProducts: Product[] = [
  {
    slug: "shade-nets",
    name: "Shade Nets",
    spec: "35–75% SHADE",
    description:
      "UV-stabilised shade netting in multiple densities, supplied for nurseries, greenhouses and open storage yards.",
    uses: ["Nurseries", "Greenhouses", "Open storage yards"],
  },
  {
    slug: "sun-protection-nets",
    name: "Sun Protection Nets",
    spec: "HEAT REDUCTION",
    description:
      "Heavy-density netting engineered to cut peak summer heat for livestock shelters and outdoor workspaces.",
    uses: ["Livestock shelters", "Parking & yards", "Outdoor workstations"],
  },
  {
    slug: "farming-nets",
    name: "Farming Nets",
    spec: "CROP GRADE",
    description:
      "Purpose-built netting for crop protection, climbing support, and seasonal field coverage.",
    uses: ["Crop protection", "Climbing support", "Field coverage"],
  },
  {
    slug: "garden-nets",
    name: "Garden Nets",
    spec: "LIGHTWEIGHT",
    description:
      "Lightweight, easy-to-install netting for home gardens, terraces and small commercial plots.",
    uses: ["Home gardens", "Terrace plots", "Plant support"],
  },
  {
    slug: "bird-protection-nets",
    name: "Bird Protection Nets",
    spec: "FINE MESH",
    description:
      "Fine-mesh, low-visibility netting that keeps birds off crops, balconies and warehouse openings without harm.",
    uses: ["Orchard protection", "Balconies", "Warehouse openings"],
  },
  {
    slug: "safety-nets",
    name: "Safety Nets",
    spec: "FALL RATED",
    description:
      "Heavy-grade safety netting for construction sites and elevated work areas, supplied to commercial contractors.",
    uses: ["Construction sites", "Elevated platforms", "Industrial safety zones"],
  },
];

export const hardwareCategories: Product[] = [
  {
    slug: "industrial-hardware",
    name: "Industrial Hardware",
    spec: "BULK SUPPLY",
    description:
      "Shackles, hooks, buckles, rings and fittings supplied in bulk to factories, transporters and rigging contractors.",
    uses: ["Shackles & hooks", "Buckles & rings", "Rigging fittings"],
  },
  {
    slug: "commercial-hardware",
    name: "Commercial Hardware",
    spec: "TRADE SUPPLY",
    description:
      "A reliable range of commercial-grade hardware for shops, contractors, and recurring trade requirements.",
    uses: ["Fasteners", "Fittings", "Trade essentials"],
  },
  {
    slug: "general-hardware",
    name: "General Hardware Supply",
    spec: "EVERYDAY STOCK",
    description:
      "The everyday hardware stock our customers have relied on since 1970 — sourced, stocked, and always on hand.",
    uses: ["Everyday tools", "Maintenance supplies", "Walk-in requirements"],
  },
];

export const serviceCities = [
  "Indore",
  "Ujjain",
  "Bhopal",
  "Ratlam",
  "Neemuch",
  "Mandsaur",
  "Kota",
  "Pithampur",
];

export const reviews = [
  {
    name: "Rajesh Patidar",
    role: "Transport Fleet Owner, Indore",
    rating: 5,
    text: "We've sourced our lashing rope from Standard Rope for over 8 years. Quality has never once been inconsistent.",
  },
  {
    name: "Sunita Agro Farms",
    role: "Agricultural Supplier, Dewas",
    rating: 5,
    text: "Their shade nets held up through three full summers. Genuinely durable, and they always have stock ready.",
  },
  {
    name: "Vikram Construction Co.",
    role: "Site Contractor, Ujjain",
    rating: 5,
    text: "Bulk orders for scaffolding rope are handled fast, and Aziz bhai personally checks every order before dispatch.",
  },
  {
    name: "Mahesh Warehousing",
    role: "Logistics Manager, Pithampur",
    rating: 5,
    text: "Fifty years in business shows. They know exactly which rope grade suits which load — saved us from a wrong order twice.",
  },
  {
    name: "Govind Dairy & Farms",
    role: "Livestock Owner, Ratlam",
    rating: 5,
    text: "Soft-hand animal rope that doesn't chafe, and fair pricing every time. A trusted name in this region.",
  },
  {
    name: "Om Steel Traders",
    role: "Industrial Buyer, Bhopal",
    rating: 5,
    text: "Their hardware stock covers nearly everything we need for our unit. One supplier, one phone call, no delays.",
  },
];
