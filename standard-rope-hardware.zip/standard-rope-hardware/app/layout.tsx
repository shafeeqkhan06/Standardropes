import type { Metadata } from "next";
import { Big_Shoulders_Display, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WelcomeScreen from "@/components/WelcomeScreen";
import AIAssistant from "@/components/AIAssistant";

const display = Big_Shoulders_Display({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-display",
});
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

export const metadata: Metadata = {
  metadataBase: new URL("https://standardropehardware.in"),
  title: {
    default: "Standard Rope & Hardware | Trusted Rope, Net & Hardware Solutions Since 1970",
    template: "%s | Standard Rope & Hardware",
  },
  description:
    "Standard Rope & Hardware supplies industrial, agricultural, construction and transport rope, nets and hardware to businesses across Central India. Trusted in Dewas, Madhya Pradesh since 1970.",
  keywords: [
    "rope supplier Dewas",
    "industrial rope Madhya Pradesh",
    "shade nets supplier",
    "hardware supplier Dewas",
    "Standard Rope and Hardware",
  ],
  openGraph: {
    title: "Standard Rope & Hardware",
    description: "Trusted Rope, Net & Hardware Solutions Since 1970",
    locale: "en_IN",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${display.variable} ${body.variable} ${mono.variable} font-body antialiased`}>
        <WelcomeScreen />
        <Navbar />
        <main>{children}</main>
        <Footer />
        <AIAssistant />
      </body>
    </html>
  );
}
