import type { Metadata } from "next";
import { MessageSquareText } from "lucide-react";
import { whatsappLink, callLink } from "@/lib/data";

export const metadata: Metadata = {
  title: "Standard Rope Expert — AI Assistant",
  description: "Chat with the Standard Rope Expert for product guidance and recommendations.",
};

export default function AIAssistantPage() {
  return (
    <section className="pt-40 pb-24 bg-mist-gradient min-h-[80vh]">
      <div className="max-w-2xl mx-auto px-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-sky-gradient text-white flex items-center justify-center mx-auto mb-6 shadow-premium">
          <MessageSquareText size={28} />
        </div>
        <p className="eyebrow text-deep mb-3">Standard Rope Expert</p>
        <h1 className="font-display text-4xl md:text-5xl text-deep-900 mb-5">
          Get Instant Product Guidance
        </h1>
        <p className="text-ink/60 leading-relaxed mb-8">
          Use the chat icon in the bottom-right corner of any page to ask
          about rope grades, net densities, hardware availability, or to
          get redirected straight to WhatsApp for a detailed quote.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient shadow-premium">
            Chat on WhatsApp
          </a>
          <a href={callLink} className="px-7 py-3.5 rounded-full font-semibold text-deep border border-deep/20">
            Call Aziz Ur Rahman Khan
          </a>
        </div>
      </div>
    </section>
  );
}
