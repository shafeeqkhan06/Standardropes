import Image from "next/image";
import type { Metadata } from "next";
import { timeline, business } from "@/lib/data";
import RopeDivider from "@/components/RopeDivider";

export const metadata: Metadata = {
  title: "About Us — A Legacy of Trust Since 1970",
  description:
    "The story of Standard Rope & Hardware — three generations supplying rope, net and hardware solutions from Dewas, Madhya Pradesh since 1970.",
};

export default function AboutPage() {
  return (
    <>
      <section className="pt-40 pb-20 bg-deep-900 text-center relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-25"
          style={{
            background: "radial-gradient(circle at 50% 0%, rgba(79,195,247,0.45), transparent 60%)",
          }}
        />
        <div className="relative max-w-3xl mx-auto px-6">
          <p className="eyebrow text-sky-400 mb-4">About Standard Rope &amp; Hardware</p>
          <h1 className="font-display text-4xl md:text-6xl text-white">
            A Legacy of Trust Since 1970
          </h1>
          <p className="text-white/55 mt-5 leading-relaxed">
            Three generations of one Dewas family, dedicated to a single
            trade: supplying rope, net and hardware that businesses can rely on.
          </p>
        </div>
      </section>

      <section className="section-pad bg-white">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="relative rounded-3xl overflow-hidden shadow-premium aspect-[4/3] order-2 lg:order-1">
            <Image
              src="/images/shopfront.png"
              alt="Standard Rope & Hardware shop in Dewas"
              fill
              className="object-cover"
            />
          </div>
          <div className="order-1 lg:order-2">
            <p className="eyebrow text-deep mb-3">Where It Began</p>
            <h2 className="font-display text-3xl md:text-4xl text-deep-900 mb-5 leading-tight">
              Raja Ram Patel Market, Dewas
            </h2>
            <p className="text-ink/65 leading-relaxed mb-4">
              {business.owner} carries forward a business his family built
              counter by counter — from hand-laid cotton rope sold to local
              farmers, to becoming a recognised supplier for industries,
              transport companies and construction firms across Central
              India.
            </p>
            <p className="text-ink/65 leading-relaxed">
              The address has stayed the same for over five decades. What&apos;s
              changed is the scale of who relies on it.
            </p>
          </div>
        </div>

        <RopeDivider knotted className="max-w-4xl mx-auto mb-16" />

        {/* TIMELINE */}
        <div className="max-w-3xl mx-auto px-6">
          <p className="eyebrow text-deep text-center mb-3">The Journey</p>
          <h2 className="font-display text-3xl md:text-4xl text-deep-900 text-center mb-16">
            Five Decades, One Address
          </h2>
          <div className="relative pl-8 border-l-2 border-sky/30 space-y-12">
            {timeline.map((t) => (
              <div key={t.year} className="relative">
                <span className="absolute -left-[39px] top-1 w-5 h-5 rounded-full bg-white border-2 border-sky shadow-glass" />
                <p className="font-mono text-xs tracking-widest2 text-deep mb-1">{t.year}</p>
                <h3 className="font-display text-2xl text-deep-900 mb-2">{t.title}</h3>
                <p className="text-ink/60 leading-relaxed">{t.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
