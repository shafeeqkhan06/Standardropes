import type { Metadata } from "next";
import Link from "next/link";
import { hardwareCategories, whatsappLink } from "@/lib/data";
import { Layers } from "lucide-react";

export const metadata: Metadata = {
  title: "Hardware Solutions — Industrial & Commercial Hardware Supply",
  description:
    "Industrial, commercial and general hardware supply from Standard Rope & Hardware, Dewas — serving factories, contractors and trade businesses.",
};

export default function HardwareSolutionsPage() {
  return (
    <>
      <section className="pt-40 pb-20 bg-deep-900 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-25"
          style={{ background: "radial-gradient(circle at 20% 30%, rgba(79,195,247,0.5), transparent 55%)" }}
        />
        <div className="relative max-w-3xl mx-auto px-6 text-center">
          <p className="eyebrow text-sky-400 mb-4">Hardware Solutions</p>
          <h1 className="font-display text-4xl md:text-6xl text-white leading-[0.98]">
            Hardware Supply Built on Five Decades of Trust
          </h1>
          <p className="text-white/55 mt-5 leading-relaxed">
            From shackles and fittings to everyday trade essentials — one
            reliable source, stocked and ready.
          </p>
        </div>
      </section>

      <section className="section-pad bg-white">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {hardwareCategories.map((h, i) => (
            <div key={h.slug} className="relative p-8 rounded-3xl border border-slate-100 bg-mist hover:shadow-premium transition-all duration-300">
              <div className="w-12 h-12 rounded-xl bg-sky-gradient flex items-center justify-center text-white mb-6">
                <Layers size={22} />
              </div>
              <span className="spec-tag mb-3 inline-block">{h.spec}</span>
              <h3 className="font-display text-2xl text-deep-900 mb-2">{h.name}</h3>
              <p className="text-sm text-ink/60 leading-relaxed mb-5">{h.description}</p>
              <ul className="space-y-1.5">
                {h.uses.map((u) => (
                  <li key={u} className="text-xs text-ink/55 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-sky" /> {u}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="section-pad bg-mist text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="font-display text-3xl md:text-4xl text-deep-900 mb-4">
            Looking for a Specific Fitting?
          </h2>
          <p className="text-ink/60 mb-8">
            We supply hardware for industrial, commercial and general use —
            send us your requirement and we&apos;ll confirm availability.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient shadow-premium">
              WhatsApp Us
            </a>
            <Link href="/contact" className="px-7 py-3.5 rounded-full font-semibold text-deep border border-deep/20">
              Request Quote
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
