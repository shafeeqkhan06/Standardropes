import Link from "next/link";
import Image from "next/image";
import { ArrowRight, ShieldCheck, Package, Wrench } from "lucide-react";
import { business, whatsappLink } from "@/lib/data";
import TrustCounters from "@/components/TrustCounters";
import ServiceArea from "@/components/ServiceArea";
import RopeDivider from "@/components/RopeDivider";

const categories = [
  {
    href: "/rope-solutions",
    icon: Package,
    title: "Rope Solutions",
    text: "Nylon, industrial, agricultural, transport, construction and heavy-duty rope.",
  },
  {
    href: "/net-solutions",
    icon: ShieldCheck,
    title: "Net Solutions",
    text: "Shade, sun-protection, farming, garden, bird-protection and safety nets.",
  },
  {
    href: "/hardware-solutions",
    icon: Wrench,
    title: "Hardware Solutions",
    text: "Industrial, commercial and general hardware supply for every requirement.",
  },
];

export default function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative pt-44 pb-28 overflow-hidden bg-deep-900">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            background:
              "radial-gradient(circle at 20% 20%, rgba(79,195,247,0.5), transparent 55%), radial-gradient(circle at 85% 75%, rgba(79,195,247,0.35), transparent 50%)",
          }}
        />
        {/* coiled rope decorative SVG */}
        <svg
          viewBox="0 0 600 600"
          className="absolute -right-32 top-1/2 -translate-y-1/2 w-[640px] h-[640px] opacity-[0.14] pointer-events-none hidden lg:block"
        >
          <g fill="none" stroke="#4FC3F7" strokeWidth="6">
            {Array.from({ length: 9 }).map((_, i) => (
              <circle key={i} cx="300" cy="300" r={40 + i * 28} />
            ))}
          </g>
        </svg>

        <div className="relative max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <p className="eyebrow text-sky-400 mb-5">Est. 1970 · Dewas, Madhya Pradesh</p>
          <h1 className="font-display text-[clamp(2.6rem,8vw,6.2rem)] leading-[0.95] text-white tracking-tight">
            STANDARD ROPE
            <br />
            <span className="text-sky-400">&amp; HARDWARE</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-sky-100/90 font-medium">
            {business.tagline}
          </p>
          <p className="mt-4 max-w-2xl mx-auto text-white/55 leading-relaxed">
            Serving industries, farms, warehouses, transport businesses and
            commercial clients across Central India with reliable rope, net
            and hardware solutions.
          </p>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <Link
              href="/contact"
              className="px-7 py-3.5 rounded-full font-semibold text-deep-900 bg-white hover:bg-sky-100 transition-colors shadow-premium"
            >
              Request Quote
            </Link>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient hover:scale-[1.03] transition-transform shadow-premium"
            >
              WhatsApp Now
            </a>
            <Link
              href="/rope-solutions"
              className="px-7 py-3.5 rounded-full font-semibold text-white/85 border border-white/25 hover:border-white/60 transition-colors flex items-center gap-2"
            >
              Explore Products <ArrowRight size={17} />
            </Link>
          </div>
        </div>
      </section>

      <TrustCounters />

      {/* CATEGORY TEASERS */}
      <section className="section-pad bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14 max-w-2xl mx-auto">
            <p className="eyebrow text-deep">What We Supply</p>
            <h2 className="font-display text-3xl md:text-5xl text-deep-900 mt-3">
              Three Pillars of Industrial Supply
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-7">
            {categories.map((c) => (
              <Link
                key={c.href}
                href={c.href}
                className="group relative p-8 rounded-3xl border border-slate-100 bg-mist hover:bg-white hover:shadow-premium transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-2xl bg-sky-gradient flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform">
                  <c.icon size={26} />
                </div>
                <h3 className="font-display text-2xl text-deep-900 mb-2">{c.title}</h3>
                <p className="text-sm text-ink/60 leading-relaxed mb-6">{c.text}</p>
                <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-deep">
                  View Range
                  <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <RopeDivider knotted />

      {/* LEGACY STRIP */}
      <section className="section-pad bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="eyebrow text-deep">Our Story</p>
            <h2 className="font-display text-3xl md:text-4xl text-deep-900 mt-3 mb-5 leading-tight">
              A Legacy of Trust Since 1970
            </h2>
            <p className="text-ink/65 leading-relaxed mb-6">
              What began as a single rope counter in Dewas&apos; Raja Ram
              Patel Market has grown into a trusted regional supplier to
              industries, farms, transporters and construction companies —
              still run with the same hands-on attention to quality, three
              generations later.
            </p>
            <Link
              href="/about"
              className="inline-flex items-center gap-2 font-semibold text-deep group"
            >
              Read Our Full Story
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          <div className="relative rounded-3xl overflow-hidden shadow-premium aspect-[4/3]">
            <Image
              src="/images/shopfront.png"
              alt="Standard Rope & Hardware storefront in Dewas"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-deep-900/50 via-transparent to-transparent" />
          </div>
        </div>
      </section>

      <ServiceArea />
    </>
  );
}
