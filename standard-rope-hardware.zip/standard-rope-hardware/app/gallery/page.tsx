import type { Metadata } from "next";
import GalleryClient from "@/components/GalleryClient";

export const metadata: Metadata = {
  title: "Gallery",
  description: "A look inside Standard Rope & Hardware — Dewas, Madhya Pradesh.",
};

export default function GalleryPage() {
  return (
    <section className="pt-40 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <p className="eyebrow text-deep">Gallery</p>
          <h1 className="font-display text-4xl md:text-5xl text-deep-900 mt-3">
            Inside Standard Rope &amp; Hardware
          </h1>
          <p className="text-ink/60 mt-4">
            A look at our shop, stock and the products that have earned
            trust since 1970. More product photography is being added
            regularly.
          </p>
        </div>
        <GalleryClient />
      </div>
    </section>
  );
}
