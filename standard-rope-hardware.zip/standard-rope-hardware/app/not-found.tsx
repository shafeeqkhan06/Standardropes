import Link from "next/link";

export default function NotFound() {
  return (
    <section className="min-h-[80vh] flex items-center justify-center bg-deep-900 text-center px-6">
      <div>
        <p className="font-mono text-sky-400 tracking-widest2 text-sm mb-4">ERROR 404</p>
        <h1 className="font-display text-5xl md:text-7xl text-white mb-5">
          End of the Line
        </h1>
        <p className="text-white/55 max-w-md mx-auto mb-8">
          This page has come loose. Let&apos;s get you back to solid ground.
        </p>
        <Link
          href="/"
          className="px-7 py-3.5 rounded-full font-semibold text-deep-900 bg-white inline-block"
        >
          Back to Home
        </Link>
      </div>
    </section>
  );
}
