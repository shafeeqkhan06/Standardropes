import type { Metadata } from "next";
import Link from "next/link";
import { ropeProducts, whatsappLink } from "@/lib/data";
import ProductCard from "@/components/ProductCard";
import RopeDivider from "@/components/RopeDivider";
import { Factory, Tractor, Truck, HardHat } from "lucide-react";

export const metadata: Metadata = {
  title: "Rope Solutions — Industrial, Agricultural & Transport Rope",
  description:
    "Nylon, industrial, agricultural, animal, transport, construction, heavy-duty and multipurpose rope supplied in bulk across Central India by Standard Rope & Hardware.",
};

const industries = [
  { icon: Factory, title: "Industries & Factories", text: "Hoisting, machine tie-downs, and material handling rope built for daily heavy use." },
  { icon: Tractor, title: "Agricultural Businesses", text: "Fencing, baling and tethering rope that holds up through every season." },
  { icon: Truck, title: "Transport Companies", text: "High-tensile load-securing rope trusted on long-haul routes across the region." },
  { icon: HardHat, title: "Construction Companies", text: "Scaffolding ties, hoisting lines and site-safety rope for active job sites." },
];

export default function RopeSolutionsPage() {
  return (
    <>
      <section className="pt-40 pb-20 bg-deep-900 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-25"
          style={{ background: "radial-gradient(circle at 80% 20%, rgba(79,195,247,0.5), transparent 55%)" }}
        />
        <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
          <p className="eyebrow text-sky-400 mb-4">Our Core Trade</p>
          <h1 className="font-display text-4xl md:text-6xl text-white max-w-2xl leading-[0.98]">
            Rope Solutions for Every Industrial Need
          </h1>
          <p className="text-white/55 mt-5 max-w-xl leading-relaxed">
            Eight rope categories, stocked and supplied in bulk — from
            farmland fencing to crane-rated heavy lifting. Every coil
            specced for the load it&apos;s built to carry.
          </p>
        </div>
      </section>

      {/* APPLICATIONS */}
      <section className="section-pad bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14 max-w-2xl mx-auto">
            <p className="eyebrow text-deep">Built For</p>
            <h2 className="font-display text-3xl md:text-4xl text-deep-900 mt-3">
              Who Relies on Our Rope
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {industries.map((ind) => (
              <div key={ind.title} className="p-6 rounded-2xl bg-mist border border-slate-100">
                <ind.icon className="text-deep mb-4" size={28} />
                <h3 className="font-display text-lg text-deep-900 mb-2">{ind.title}</h3>
                <p className="text-sm text-ink/60 leading-relaxed">{ind.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <RopeDivider knotted />

      {/* PRODUCT GRID */}
      <section className="section-pad bg-mist">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14 max-w-2xl mx-auto">
            <p className="eyebrow text-deep">The Range</p>
            <h2 className="font-display text-3xl md:text-4xl text-deep-900 mt-3">
              Eight Rope Categories, Fully Stocked
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {ropeProducts.map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-pad bg-deep-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="font-display text-3xl md:text-4xl text-white mb-4">
            Need a Specific Grade or Bulk Quantity?
          </h2>
          <p className="text-white/55 mb-8">
            Tell us your application and load requirement — we&apos;ll
            recommend the right rope and send a quote.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient shadow-premium">
              WhatsApp Us
            </a>
            <Link href="/contact" className="px-7 py-3.5 rounded-full font-semibold text-white border border-white/25">
              Request Quote
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
