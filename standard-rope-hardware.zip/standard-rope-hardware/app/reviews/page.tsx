import type { Metadata } from "next";
import { Star } from "lucide-react";
import { reviews } from "@/lib/data";

export const metadata: Metadata = {
  title: "Customer Reviews",
  description: "What businesses across Central India say about Standard Rope & Hardware.",
};

export default function ReviewsPage() {
  return (
    <section className="pt-40 pb-24 bg-mist-gradient">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <p className="eyebrow text-deep">Reviews</p>
          <h1 className="font-display text-4xl md:text-5xl text-deep-900 mt-3">
            Trusted by Businesses Across Central India
          </h1>
          <div className="flex items-center justify-center gap-1 mt-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={22} fill="#4FC3F7" stroke="#4FC3F7" />
            ))}
          </div>
          <p className="text-ink/60 mt-3 text-sm">
            Built on five decades of consistent service, not just recent reviews.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((r) => (
            <div key={r.name} className="bg-white rounded-2xl p-6 shadow-glass border border-slate-100">
              <div className="flex items-center gap-1 mb-3">
                {Array.from({ length: r.rating }).map((_, i) => (
                  <Star key={i} size={15} fill="#4FC3F7" stroke="#4FC3F7" />
                ))}
              </div>
              <p className="text-sm text-ink/70 leading-relaxed mb-5">&ldquo;{r.text}&rdquo;</p>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-sky-gradient text-white flex items-center justify-center text-sm font-semibold">
                  {r.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-semibold text-deep-900">{r.name}</p>
                  <p className="text-xs text-ink/50">{r.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
