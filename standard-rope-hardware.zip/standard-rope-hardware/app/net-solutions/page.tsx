import type { Metadata } from "next";
import Link from "next/link";
import { netProducts, whatsappLink } from "@/lib/data";
import ProductCard from "@/components/ProductCard";

export const metadata: Metadata = {
  title: "Net Solutions — Shade, Farming & Safety Nets",
  description:
    "Shade nets, sun protection nets, farming and garden nets, bird protection and safety nets supplied across Central India by Standard Rope & Hardware.",
};

export default function NetSolutionsPage() {
  return (
    <>
      <section className="pt-40 pb-24 bg-sky-gradient relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
          <div>
            <p className="eyebrow text-white/80 mb-4">Net Solutions</p>
            <h1 className="font-display text-4xl md:text-6xl text-white leading-[0.98]">
              Protection That Holds Through Every Season
            </h1>
            <p className="text-white/85 mt-5 max-w-md leading-relaxed">
              From nursery shade to construction-site safety, our net range
              is built for Central India&apos;s heat, dust and monsoon.
            </p>
          </div>
          <div className="hidden lg:block">
            <svg viewBox="0 0 200 200" className="w-full opacity-90">
              <defs>
                <pattern id="meshPattern" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M0,0 L20,20 M20,0 L0,20" stroke="white" strokeWidth="1" opacity="0.5" />
                </pattern>
              </defs>
              <rect width="200" height="200" rx="24" fill="url(#meshPattern)" />
            </svg>
          </div>
        </div>
      </section>

      <section className="section-pad bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-14 max-w-2xl mx-auto">
            <p className="eyebrow text-deep">The Range</p>
            <h2 className="font-display text-3xl md:text-4xl text-deep-900 mt-3">
              Six Net Categories for Every Application
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {netProducts.map((p, i) => (
              <ProductCard key={p.slug} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="section-pad bg-mist text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="font-display text-3xl md:text-4xl text-deep-900 mb-4">
            Not Sure Which Density You Need?
          </h2>
          <p className="text-ink/60 mb-8">
            Tell us the application and we&apos;ll recommend the right shade
            percentage and mesh size.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient shadow-premium">
              WhatsApp Us
            </a>
            <Link href="/contact" className="px-7 py-3.5 rounded-full font-semibold text-deep border border-deep/20">
              Request Quote
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
