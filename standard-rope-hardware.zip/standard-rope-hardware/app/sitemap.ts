import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://standardropehardware.in";
  const routes = [
    "",
    "/about",
    "/rope-solutions",
    "/net-solutions",
    "/hardware-solutions",
    "/gallery",
    "/reviews",
    "/contact",
    "/ai-assistant",
  ];
  return routes.map((r) => ({
    url: `${base}${r}`,
    lastModified: new Date(),
    changeFrequency: "monthly",
    priority: r === "" ? 1 : 0.7,
  }));
}
