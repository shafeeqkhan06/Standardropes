import type { Metadata } from "next";
import { MapPin, Phone, MessageCircle, Clock } from "lucide-react";
import { business, whatsappLink, callLink } from "@/lib/data";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Standard Rope & Hardware, Dewas — call, WhatsApp, or send an inquiry for rope, net and hardware solutions.",
};

export default function ContactPage() {
  return (
    <section className="pt-40 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <p className="eyebrow text-deep">Contact</p>
          <h1 className="font-display text-4xl md:text-5xl text-deep-900 mt-3">
            Let&apos;s Talk About Your Requirement
          </h1>
          <p className="text-ink/60 mt-4">
            Call, WhatsApp, or send an inquiry below — {business.owner} personally handles every order.
          </p>
        </div>

        <div className="grid lg:grid-cols-[0.85fr_1.15fr] gap-10">
          <div className="space-y-5">
            <div className="bg-mist rounded-2xl p-6 border border-slate-100">
              <div className="flex gap-3 items-start">
                <MapPin className="text-deep shrink-0 mt-1" size={20} />
                <div>
                  <p className="font-semibold text-deep-900 text-sm mb-1">Address</p>
                  <p className="text-sm text-ink/60 leading-relaxed">
                    {business.address.line1}<br />
                    {business.address.line2}<br />
                    {business.address.line3}
                  </p>
                </div>
              </div>
            </div>
            <div className="bg-mist rounded-2xl p-6 border border-slate-100">
              <div className="flex gap-3 items-start">
                <Phone className="text-deep shrink-0 mt-1" size={20} />
                <div>
                  <p className="font-semibold text-deep-900 text-sm mb-1">Phone</p>
                  <a href={callLink} className="text-sm text-ink/60 hover:text-deep">{business.phoneDisplay}</a>
                </div>
              </div>
            </div>
            <div className="bg-mist rounded-2xl p-6 border border-slate-100">
              <div className="flex gap-3 items-start">
                <MessageCircle className="text-deep shrink-0 mt-1" size={20} />
                <div>
                  <p className="font-semibold text-deep-900 text-sm mb-1">WhatsApp</p>
                  <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="text-sm text-ink/60 hover:text-deep">
                    {business.phoneDisplay}
                  </a>
                </div>
              </div>
            </div>
            <div className="bg-mist rounded-2xl p-6 border border-slate-100">
              <div className="flex gap-3 items-start">
                <Clock className="text-deep shrink-0 mt-1" size={20} />
                <div>
                  <p className="font-semibold text-deep-900 text-sm mb-1">Hours</p>
                  <p className="text-sm text-ink/60">Mon – Sat, 10:00 AM – 8:00 PM</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl overflow-hidden border border-slate-100 h-56">
              <iframe
                title="Standard Rope & Hardware location"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                src="https://www.google.com/maps?q=Raja+Ram+Patel+Market+Dewas+Madhya+Pradesh&output=embed"
              />
            </div>
          </div>

          <div className="bg-mist-gradient rounded-3xl p-8 lg:p-10 shadow-glass border border-slate-100">
            <h2 className="font-display text-2xl text-deep-900 mb-6">Send an Inquiry</h2>
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}
