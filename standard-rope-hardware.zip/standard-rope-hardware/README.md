# Standard Rope & Hardware — Website

A premium industrial-brand website for Standard Rope & Hardware (Dewas, Madhya Pradesh, est. 1970), built with Next.js 14 (App Router), TypeScript, Tailwind CSS and Framer Motion.

## Run it locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Build for production

```bash
npm run build
npm start
```

## Deploy

This is a standard Next.js app — deploy directly to **Vercel** (recommended, zero config) or any Node host. For Vercel: push this folder to a GitHub repo, then "Import Project" on vercel.com.

## Structure

- `app/` — one folder per page (App Router). Each page has its own `metadata` export for SEO.
- `components/` — shared UI: Navbar, Footer, the Bismillah welcome screen, the floating "Standard Rope Expert" AI assistant, the signature rope-thread divider, product cards, trust counters, and the service-area map section.
- `lib/data.ts` — single source of truth for business info, navigation, product lists, reviews, timeline and service-area cities. Edit this file to update content site-wide without touching component code.
- `public/images/` — logo and shop photo.

## Things to do before launch

1. **Logo & shop photo** — the uploaded logo and shop photo are in `public/images/`. The brief asked for an AI-cleaned-up logo (single "1970", vector finish) and a relit/re-signed shop photo — these can be regenerated and dropped into the same filenames (`logo.png`, `shopfront.png`) once produced.
2. **Real product photography** — the Gallery and product pages currently use placeholder tiles/icons for rope, net and hardware categories (no stock photography was available to source). Replace with real photos for the strongest result.
3. **Domain** — `app/layout.tsx` and `app/sitemap.ts` use a placeholder domain (`standardropehardware.in`). Update to the real domain before going live.
4. **Google Maps** — the embed on the Contact page uses a text-based query; once you have a verified Google Business Profile, swap in the exact place embed URL.
5. **AI Assistant** — currently a rule-based responder (keyword matching) that redirects to WhatsApp/Call for anything beyond basic guidance. It can be upgraded to a real LLM-backed assistant later if needed.

## Brand tokens (in `tailwind.config.ts` / `app/globals.css`)

- Sky Blue `#4FC3F7` (primary), Deep Blue `#0D47A1` (secondary), white background, soft grey surfaces, plus a muted rope-tan `#C9A877` used sparingly as a signature accent.
- Display face: Big Shoulders Display (condensed industrial headlines). Body: Inter. Spec/mono labels: JetBrains Mono.
- Signature element: a continuous twisted-rope line (`components/RopeDivider.tsx`) used as a structural divider between sections instead of a plain rule.
