import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        sky: {
          DEFAULT: "#4FC3F7",
          50: "#EFFAFE",
          100: "#D9F2FD",
          400: "#4FC3F7",
        },
        deep: {
          DEFAULT: "#0D47A1",
          900: "#0A1929",
        },
        mist: "#F1F5F9",
        rope: {
          DEFAULT: "#C9A877",
          light: "#E4D3B0",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      boxShadow: {
        premium: "0 20px 60px -15px rgba(13, 71, 161, 0.25)",
        glass: "0 8px 32px rgba(13, 71, 161, 0.12)",
      },
      backgroundImage: {
        "sky-gradient": "linear-gradient(135deg, #4FC3F7 0%, #0D47A1 100%)",
        "mist-gradient": "linear-gradient(180deg, #FFFFFF 0%, #F1F5F9 100%)",
      },
      letterSpacing: {
        widest2: "0.22em",
      },
    },
  },
  plugins: [],
};
export default config;
