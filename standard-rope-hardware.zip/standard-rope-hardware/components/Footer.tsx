import Link from "next/link";
import Image from "next/image";
import { MapPin, Phone, MessageCircle } from "lucide-react";
import { business, navLinks, whatsappLink, callLink } from "@/lib/data";
import RopeDivider from "./RopeDivider";

export default function Footer() {
  return (
    <footer className="bg-deep-900 text-white pt-4">
      <RopeDivider className="opacity-40" />
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-14 grid gap-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5 mb-4">
            <Image
              src="/images/logo.png"
              alt="Standard Rope & Hardware"
              width={40}
              height={40}
              className="rounded-md"
            />
            <p className="font-display text-base tracking-wide">STANDARD ROPE</p>
          </div>
          <p className="text-white/60 text-sm leading-relaxed">
            {business.tagline}
          </p>
        </div>

        <div>
          <p className="eyebrow text-sky-400 mb-4">Navigate</p>
          <ul className="space-y-2.5 text-sm text-white/70">
            {navLinks.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="hover:text-sky-400 transition-colors">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="eyebrow text-sky-400 mb-4">Reach Us</p>
          <ul className="space-y-3 text-sm text-white/70">
            <li className="flex gap-2.5">
              <MapPin size={17} className="shrink-0 mt-0.5 text-sky-400" />
              {business.address.full}
            </li>
            <li className="flex gap-2.5">
              <Phone size={17} className="shrink-0 mt-0.5 text-sky-400" />
              <a href={callLink} className="hover:text-sky-400">{business.phoneDisplay}</a>
            </li>
            <li className="flex gap-2.5">
              <MessageCircle size={17} className="shrink-0 mt-0.5 text-sky-400" />
              <a href={whatsappLink} className="hover:text-sky-400">WhatsApp Us</a>
            </li>
          </ul>
        </div>

        <div>
          <p className="eyebrow text-sky-400 mb-4">Since</p>
          <p className="font-display text-5xl">1970</p>
          <p className="text-white/50 text-sm mt-2">
            Three generations of rope, net &amp; hardware expertise in Dewas, Madhya Pradesh.
          </p>
        </div>
      </div>

      <div className="border-t border-white/10 py-5 text-center text-xs text-white/40">
        © {new Date().getFullYear()} {business.name}. Proprietor {business.owner}. All rights reserved.
      </div>
    </footer>
  );
}
