"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

const items = [
  { src: "/images/shopfront.png", alt: "Standard Rope & Hardware storefront, Dewas", tall: true },
];

// Placeholder tiles for product categories until real photography is added.
const placeholders = [
  { label: "Nylon & Industrial Rope", tall: false },
  { label: "Agricultural Rope", tall: true },
  { label: "Transport & Construction Rope", tall: false },
  { label: "Shade Nets", tall: false },
  { label: "Safety Nets", tall: true },
  { label: "Hardware Fittings", tall: false },
  { label: "Heavy Duty Rope Coils", tall: false },
  { label: "Garden Nets", tall: true },
];

export default function GalleryClient() {
  const [active, setActive] = useState<string | null>(null);

  return (
    <>
      <div className="columns-1 sm:columns-2 lg:columns-4 gap-5 [&>*]:mb-5">
        <button
          onClick={() => setActive(items[0].src)}
          className={`relative w-full rounded-2xl overflow-hidden group block break-inside-avoid ${items[0].tall ? "aspect-[3/4]" : "aspect-square"}`}
        >
          <Image src={items[0].src} alt={items[0].alt} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
          <div className="absolute inset-0 bg-deep-900/0 group-hover:bg-deep-900/30 transition-colors flex items-end p-4">
            <span className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
              {items[0].alt}
            </span>
          </div>
        </button>

        {placeholders.map((p) => (
          <div
            key={p.label}
            className={`relative w-full rounded-2xl overflow-hidden bg-gradient-to-br from-sky/20 via-mist to-deep/10 border border-slate-100 flex items-center justify-center p-6 text-center break-inside-avoid ${p.tall ? "aspect-[3/4]" : "aspect-square"}`}
          >
            <span className="font-display text-deep-900/40 text-lg">{p.label}</span>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            className="fixed inset-0 z-[90] bg-deep-900/90 flex items-center justify-center p-6"
          >
            <button className="absolute top-6 right-6 text-white" aria-label="Close">
              <X size={28} />
            </button>
            <motion.div
              initial={{ scale: 0.92 }}
              animate={{ scale: 1 }}
              className="relative w-full max-w-3xl aspect-[4/3]"
              onClick={(e) => e.stopPropagation()}
            >
              <Image src={active} alt="Gallery preview" fill className="object-contain" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
