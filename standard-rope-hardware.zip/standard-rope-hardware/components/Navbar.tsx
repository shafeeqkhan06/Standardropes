"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone } from "lucide-react";
import { navLinks, whatsappLink, callLink } from "@/lib/data";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-white/85 backdrop-blur-xl shadow-glass border-b border-slate-200/60"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-8 flex items-center justify-between h-[76px]">
        <Link href="/" className="flex items-center gap-2.5 shrink-0">
          <Image
            src="/images/logo.png"
            alt="Standard Rope & Hardware"
            width={44}
            height={44}
            className="rounded-md"
            priority
          />
          <div className="leading-tight">
            <p
              className={`font-display text-lg tracking-wide ${
                scrolled ? "text-deep-900" : "text-deep"
              }`}
            >
              STANDARD ROPE
            </p>
            <p className="spec-tag !text-[0.58rem] !py-0.5">EST. 1970</p>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-7">
          {navLinks.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative text-sm font-medium tracking-wide transition-colors ${
                  active ? "text-deep" : "text-ink/70 hover:text-deep"
                }`}
              >
                {link.label}
                {active && (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute -bottom-1.5 left-0 right-0 h-[2px] bg-sky"
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="hidden lg:flex items-center gap-3">
          <Link
            href="/contact"
            className="px-5 py-2.5 rounded-full text-sm font-semibold border border-deep/20 text-deep hover:bg-deep hover:text-white transition-all"
          >
            Request Quote
          </Link>
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-sky-gradient shadow-premium hover:scale-[1.03] active:scale-[0.98] transition-transform"
          >
            WhatsApp
          </a>
        </div>

        <button
          aria-label="Toggle menu"
          className="lg:hidden p-2 text-deep"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="lg:hidden bg-white/95 backdrop-blur-xl border-t border-slate-200 overflow-hidden"
          >
            <div className="flex flex-col px-6 py-5 gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-base font-medium text-ink/80"
                >
                  {link.label}
                </Link>
              ))}
              <div className="flex gap-3 pt-3">
                <a
                  href={callLink}
                  className="flex-1 text-center py-3 rounded-full border border-deep/20 text-deep font-semibold flex items-center justify-center gap-2"
                >
                  <Phone size={16} /> Call
                </a>
                <a
                  href={whatsappLink}
                  className="flex-1 text-center py-3 rounded-full text-white bg-sky-gradient font-semibold"
                >
                  WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
