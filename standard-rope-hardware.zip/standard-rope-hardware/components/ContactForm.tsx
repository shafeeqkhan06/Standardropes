"use client";

import { useState } from "react";
import { Send } from "lucide-react";
import { business } from "@/lib/data";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", phone: "", requirement: "", message: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = encodeURIComponent(
      `Hello ${business.name},\n\nName: ${form.name}\nPhone: ${form.phone}\nRequirement: ${form.requirement}\n\n${form.message}`
    );
    window.open(`https://wa.me/${business.phone.replace("+", "")}?text=${text}`, "_blank");
  };

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-5">
        <div>
          <label className="text-xs font-semibold text-deep uppercase tracking-wide">Name</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="mt-1.5 w-full px-4 py-3 rounded-xl border border-slate-200 bg-mist focus:bg-white outline-none focus:ring-2 focus:ring-sky transition-all"
            placeholder="Your name"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-deep uppercase tracking-wide">Phone</label>
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="mt-1.5 w-full px-4 py-3 rounded-xl border border-slate-200 bg-mist focus:bg-white outline-none focus:ring-2 focus:ring-sky transition-all"
            placeholder="Phone number"
          />
        </div>
      </div>
      <div>
        <label className="text-xs font-semibold text-deep uppercase tracking-wide">Requirement</label>
        <select
          required
          value={form.requirement}
          onChange={(e) => setForm({ ...form, requirement: e.target.value })}
          className="mt-1.5 w-full px-4 py-3 rounded-xl border border-slate-200 bg-mist focus:bg-white outline-none focus:ring-2 focus:ring-sky transition-all"
        >
          <option value="">Select a category</option>
          <option>Rope Solutions</option>
          <option>Net Solutions</option>
          <option>Hardware Solutions</option>
          <option>General Inquiry</option>
        </select>
      </div>
      <div>
        <label className="text-xs font-semibold text-deep uppercase tracking-wide">Message</label>
        <textarea
          required
          rows={4}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="mt-1.5 w-full px-4 py-3 rounded-xl border border-slate-200 bg-mist focus:bg-white outline-none focus:ring-2 focus:ring-sky transition-all resize-none"
          placeholder="Tell us what you need — quantity, grade, application..."
        />
      </div>
      <button
        type="submit"
        className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full font-semibold text-white bg-sky-gradient shadow-premium hover:scale-[1.02] transition-transform"
      >
        Send Inquiry via WhatsApp <Send size={16} />
      </button>
      <p className="text-xs text-ink/45">
        Submitting opens WhatsApp with your details pre-filled — nothing is sent without your confirmation.
      </p>
    </form>
  );
}
