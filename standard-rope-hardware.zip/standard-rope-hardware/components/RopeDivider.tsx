"use client";

type Props = {
  knotted?: boolean;
  className?: string;
};

/**
 * The site's signature motif: a continuous twisted-rope line.
 * Used as a structural divider between sections instead of a plain rule.
 * `knotted` adds a small knot mid-line, used at major transitions.
 */
export default function RopeDivider({ knotted = false, className = "" }: Props) {
  return (
    <div className={`rope-thread ${className}`} aria-hidden="true">
      <svg
        viewBox="0 0 1200 28"
        preserveAspectRatio="none"
        className="w-full h-full"
      >
        <defs>
          <linearGradient id="ropeFade" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#0D47A1" stopOpacity="0" />
            <stop offset="15%" stopColor="#0D47A1" stopOpacity="0.35" />
            <stop offset="85%" stopColor="#0D47A1" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#0D47A1" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0,14 Q30,4 60,14 T120,14 T180,14 T240,14 T300,14 T360,14 T420,14 T480,14 T540,14 T600,14 T660,14 T720,14 T780,14 T840,14 T900,14 T960,14 T1020,14 T1080,14 T1140,14 T1200,14"
          fill="none"
          stroke="url(#ropeFade)"
          strokeWidth="2"
        />
        <path
          d="M0,16 Q30,26 60,16 T120,16 T180,16 T240,16 T300,16 T360,16 T420,16 T480,16 T540,16 T600,16 T660,16 T720,16 T780,16 T840,16 T900,16 T960,16 T1020,16 T1080,16 T1140,16 T1200,16"
          fill="none"
          stroke="url(#ropeFade)"
          strokeWidth="1.4"
          opacity="0.6"
        />
        {knotted && (
          <g transform="translate(600,14)">
            <circle r="6.5" fill="#F1F5F9" stroke="#C9A877" strokeWidth="1.5" />
            <path
              d="M-4,-3 Q0,-7 4,-3 Q7,0 4,3 Q0,7 -4,3 Q-7,0 -4,-3"
              fill="none"
              stroke="#0D47A1"
              strokeWidth="1.1"
            />
          </g>
        )}
      </svg>
    </div>
  );
}
