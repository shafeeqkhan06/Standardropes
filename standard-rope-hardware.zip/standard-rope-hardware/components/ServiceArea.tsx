"use client";

import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import { serviceCities } from "@/lib/data";

export default function ServiceArea() {
  return (
    <section className="section-pad bg-deep-900 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "radial-gradient(circle, #4FC3F7 1px, transparent 1px)",
          backgroundSize: "26px 26px",
        }}
      />
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative">
        <div className="text-center mb-14">
          <p className="eyebrow text-sky-400">Coverage</p>
          <h2 className="font-display text-3xl md:text-5xl text-white mt-3">
            Serving Customers Across Central India
          </h2>
          <p className="text-white/55 mt-4 max-w-xl mx-auto">
            A 500 km supply radius centred on Dewas, built over five decades of
            consistent, reliable delivery.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_1.1fr] gap-12 items-center">
          <div className="relative aspect-square max-w-md mx-auto">
            {[0, 1, 2].map((ring) => (
              <motion.div
                key={ring}
                initial={{ scale: 0.6, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: ring * 0.2 }}
                className="absolute inset-0 rounded-full border border-sky/25"
                style={{ margin: `${ring * 14}%` }}
              />
            ))}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                <div className="w-4 h-4 rounded-full bg-sky shadow-[0_0_0_8px_rgba(79,195,247,0.25)]" />
                <span className="absolute top-6 left-1/2 -translate-x-1/2 text-xs font-mono text-sky-400 whitespace-nowrap">
                  DEWAS HQ
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {serviceCities.map((city, i) => (
              <motion.div
                key={city}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="glass-dark rounded-xl px-4 py-3.5 flex items-center gap-2 text-white/85 text-sm"
              >
                <MapPin size={15} className="text-sky-400 shrink-0" />
                {city}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
