"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { whatsappLink } from "@/lib/data";
import type { Product } from "@/lib/data";

export default function ProductCard({ product, index }: { product: Product; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay: (index % 4) * 0.08 }}
      className="tassel relative bg-white rounded-2xl border border-slate-100 p-7 shadow-glass hover:shadow-premium hover:-translate-y-1.5 transition-all duration-300"
    >
      <div className="flex items-start justify-between mb-4">
        <span className="spec-tag">{product.spec}</span>
        <span className="font-mono text-xs text-ink/30">
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>
      <h3 className="font-display text-2xl text-deep-900 mb-2">{product.name}</h3>
      <p className="text-sm text-ink/65 leading-relaxed mb-5">{product.description}</p>
      <ul className="space-y-1.5 mb-6">
        {product.uses.map((u) => (
          <li key={u} className="text-xs text-ink/55 flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-sky" />
            {u}
          </li>
        ))}
      </ul>
      <a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-deep group"
      >
        Send Inquiry
        <ArrowUpRight size={16} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
      </a>
    </motion.div>
  );
}
