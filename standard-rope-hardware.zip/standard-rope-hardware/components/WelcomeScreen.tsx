"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function WelcomeScreen() {
  const [visible, setVisible] = useState(false);
  const [shown, setShown] = useState(true);

  useEffect(() => {
    if (sessionStorage.getItem("src_welcome_shown")) {
      setShown(false);
      return;
    }
    setVisible(true);
    const t1 = setTimeout(() => setVisible(false), 2600);
    const t2 = setTimeout(() => {
      setShown(false);
      sessionStorage.setItem("src_welcome_shown", "1");
    }, 3100);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (!shown) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-deep-900 overflow-hidden"
        >
          {/* floating particles */}
          {Array.from({ length: 18 }).map((_, i) => (
            <motion.span
              key={i}
              className="absolute rounded-full bg-sky/40"
              style={{
                width: 3 + (i % 4),
                height: 3 + (i % 4),
                left: `${(i * 37) % 100}%`,
                top: `${(i * 53) % 100}%`,
              }}
              animate={{
                y: [0, -24, 0],
                opacity: [0.2, 0.7, 0.2],
              }}
              transition={{
                duration: 4 + (i % 3),
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.15,
              }}
            />
          ))}

          <div className="relative text-center px-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="absolute inset-0 -z-10 blur-3xl bg-sky/20 rounded-full"
            />
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              dir="rtl"
              className="text-2xl md:text-4xl text-sky-100 font-light mb-3"
              style={{ fontFamily: "serif" }}
            >
              بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="text-white/50 text-xs tracking-widest2 uppercase font-mono"
            >
              Bismillahir Rahmanir Rahim
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
