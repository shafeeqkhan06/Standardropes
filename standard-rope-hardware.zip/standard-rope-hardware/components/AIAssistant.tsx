"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquareText, X, Send, Phone } from "lucide-react";
import { whatsappLink, callLink } from "@/lib/data";

type Msg = { from: "bot" | "user"; text: string };

const QUICK_REPLIES = [
  "I need rope for my factory",
  "Looking for shade nets",
  "Hardware for my business",
  "Talk to a person",
];

function respond(input: string): string {
  const t = input.toLowerCase();
  if (t.includes("rope")) {
    return "We supply nylon, industrial, agricultural, transport, construction, heavy-duty and multipurpose rope. What will it be used for — transport, farming, construction, or industrial machinery?";
  }
  if (t.includes("net")) {
    return "Our net range covers shade nets, sun protection nets, farming and garden nets, bird protection nets, and safety nets. Which application are you covering — a farm, garden, or construction site?";
  }
  if (t.includes("hardware")) {
    return "We stock industrial, commercial and general hardware — shackles, hooks, buckles, fittings and more. Want me to connect you with our team for exact specs and bulk pricing?";
  }
  if (t.includes("person") || t.includes("human") || t.includes("call")) {
    return "Of course — tap WhatsApp or Call below and you'll reach Aziz Ur Rahman Khan directly.";
  }
  if (t.includes("price") || t.includes("cost") || t.includes("quote")) {
    return "We don't list pricing online since every order is specced to your exact use case. Share your requirement on WhatsApp and we'll send a quote quickly.";
  }
  return "Got it. For exact specifications and bulk pricing, the fastest route is WhatsApp or a quick call — Aziz Ur Rahman Khan personally handles every inquiry.";
}

export default function AIAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { from: "bot", text: "Welcome to Standard Rope & Hardware.\nHow can I help you today?" },
  ]);
  const [input, setInput] = useState("");

  const send = (text: string) => {
    if (!text.trim()) return;
    setMessages((m) => [...m, { from: "user", text }]);
    setInput("");
    setTimeout(() => {
      setMessages((m) => [...m, { from: "bot", text: respond(text) }]);
    }, 500);
  };

  return (
    <>
      <motion.button
        aria-label="Open Standard Rope Expert assistant"
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-6 right-6 z-40 w-16 h-16 rounded-full bg-sky-gradient text-white shadow-premium flex items-center justify-center pulse-ring"
        whileTap={{ scale: 0.92 }}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}>
              <X size={26} />
            </motion.span>
          ) : (
            <motion.span key="c" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}>
              <MessageSquareText size={26} />
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            transition={{ duration: 0.25 }}
            className="fixed bottom-24 right-6 z-40 w-[min(90vw,380px)] h-[520px] rounded-3xl glass-card shadow-premium flex flex-col overflow-hidden bg-white"
          >
            <div className="bg-sky-gradient text-white px-5 py-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <MessageSquareText size={20} />
              </div>
              <div>
                <p className="font-semibold leading-tight">Standard Rope Expert</p>
                <p className="text-xs text-white/80">Usually replies in minutes</p>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-mist/40">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${
                    m.from === "bot"
                      ? "bg-white shadow-sm text-ink/90 rounded-bl-sm"
                      : "bg-sky-gradient text-white ml-auto rounded-br-sm"
                  }`}
                >
                  {m.text}
                </div>
              ))}
              {messages.length === 1 && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {QUICK_REPLIES.map((q) => (
                    <button
                      key={q}
                      onClick={() => send(q)}
                      className="text-xs px-3 py-2 rounded-full border border-deep/20 text-deep hover:bg-deep hover:text-white transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-slate-200 p-3 flex gap-2 bg-white">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send(input)}
                placeholder="Type your question..."
                className="flex-1 px-4 py-2.5 rounded-full bg-mist text-sm outline-none focus:ring-2 focus:ring-sky"
              />
              <button
                onClick={() => send(input)}
                className="w-10 h-10 rounded-full bg-sky-gradient text-white flex items-center justify-center shrink-0"
                aria-label="Send"
              >
                <Send size={16} />
              </button>
            </div>
            <div className="flex border-t border-slate-200 text-xs font-semibold">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer" className="flex-1 text-center py-3 text-deep hover:bg-mist">
                WhatsApp Us
              </a>
              <a href={callLink} className="flex-1 text-center py-3 text-deep hover:bg-mist border-l border-slate-200 flex items-center justify-center gap-1.5">
                <Phone size={13} /> Call Now
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
